//
//  CreatPath.m
//  FMDBSqlObjC
//
//  Created by cricket21 on 11/08/17.
//  Copyright © 2017 cricket21. All rights reserved.
//

#import "CreatPath.h"
#import "FMDatabase.h"
#import "DBPath.h"

@implementation CreatPath
-(void)creatPath{
    NSArray *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docPath=[path objectAtIndex:0];
    NSString *fullpath=[docPath stringByAppendingPathComponent:@"sqldatas.sqlite"];
    
     [DBPath setdbpath:fullpath];
    
    NSLog(@"db path is %@",[DBPath getdbpath]);
    
   
    
}
@end
