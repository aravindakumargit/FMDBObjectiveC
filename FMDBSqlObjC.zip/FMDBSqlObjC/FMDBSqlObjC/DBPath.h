//
//  DBPath.h
//  
//
//  Created by cricket21 on 11/08/17.
//
//

#import <Foundation/Foundation.h>

@interface DBPath : NSObject
+(void)setdbpath:(NSString*)path;
+(NSString*)getdbpath;
@end
