//
//  CreatPath.h
//  FMDBSqlObjC
//
//  Created by cricket21 on 11/08/17.
//  Copyright © 2017 cricket21. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CreatPath : NSObject
-(void)creatPath;

@end
