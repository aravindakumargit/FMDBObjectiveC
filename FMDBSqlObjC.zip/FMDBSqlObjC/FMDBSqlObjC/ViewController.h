//
//  ViewController.h
//  FMDBSqlObjC
//
//  Created by cricket21 on 11/08/17.
//  Copyright © 2017 cricket21. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FMDatabase.h"
#import "DBPath.h"
@interface ViewController : UIViewController<UIImagePickerControllerDelegate>
{
    UIImagePickerController *picker;
    UIImage *image; 
}
@property (strong, nonatomic) IBOutlet UITextField *Name;
@property (strong, nonatomic) IBOutlet UITextField *Company;
@property (strong, nonatomic) IBOutlet UITextField *PhoneNo;
@property (strong, nonatomic) IBOutlet UIDatePicker *DatePicker;
@property (strong, nonatomic) IBOutlet UIImageView *ImageView;
- (IBAction)Done:(id)sender;
@end

