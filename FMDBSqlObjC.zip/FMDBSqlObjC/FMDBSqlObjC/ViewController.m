//
//  ViewController.m
//  FMDBSqlObjC
//
//  Created by cricket21 on 11/08/17.
//  Copyright © 2017 cricket21. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self CreateTable:@"phonebook"];
    
    FMDatabase *database =[FMDatabase databaseWithPath:[DBPath getdbpath]];
    [database open];
    
    FMResultSet *resprof = [database executeQuery:@"SELECT * FROM tbl_login"];
    
    if ([resprof next]) {
        
        NSLog(@"data is %@",[resprof resultDictionary]);
    }
    
    [database close];
   }


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)CreateTable:(NSString*)tableName{
    if (![[NSFileManager defaultManager] fileExistsAtPath:[DBPath getdbpath]])
    {
        FMDatabase *database =[FMDatabase databaseWithPath:[DBPath getdbpath]];
        [database open];
        [database beginTransaction];
        BOOL res = TRUE;
        //1st profile
        res = res && [database executeUpdate:@"CREATE TABLE IF NOT EXISTS %@ (name VARCHAR, phone VARCHAR,company VARCHAR, image VARCHAR, bday VARCHAR)",tableName];
        if(res)
            [database commit];
        else
            [database rollback];
            [database close];
    }

}
- (IBAction)Done:(id)sender {
    
    
    
    NSDate *myDate = self.DatePicker.date;
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"ccc/d/MM/yyyy, hh:mm aa"];
    NSString *bday = [dateFormat stringFromDate:myDate];
    NSLog(@"pretty version %@",bday);
    
    
    FMDatabase *database =[FMDatabase databaseWithPath:[DBPath getdbpath]];
    [database open];
    [database executeUpdate:@"insert into phonebook (name,phone, company,image,bday) values(?,?,?,?,?)",self.Name.text,self.PhoneNo.text,self.Company.text,@"%@",bday];
    [database close];
}
-(void)createdata{
    FMDatabase *database =[FMDatabase databaseWithPath:[DBPath getdbpath]];
    [database open];
    
    [database executeUpdate:@"insert into tbl_login (first_name,last_name, email,phone) values(?,?,?,?)",@"Aravind",@"Arunachalam",@"aravind.auro@gmail.com",@"9790626741"];
    
    
    [database close];
}
@end
