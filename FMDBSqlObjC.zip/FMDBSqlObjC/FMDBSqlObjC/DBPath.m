//
//  DBPath.m
//  
//
//  Created by cricket21 on 11/08/17.
//
//

#import "DBPath.h"

@implementation DBPath

 static NSString *pathstr;

+(void)setdbpath:(NSString*)path{
    pathstr=path;
}
+(NSString*)getdbpath{
    return pathstr;
}
@end
